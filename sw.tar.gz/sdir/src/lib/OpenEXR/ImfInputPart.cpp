//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.
//

#include "ImfInputPart.h"
#include "ImfNamespace.h"

#include "ImfInputFile.h"
#include "ImfMultiPartInputFile.h"

OPENEXR_IMF_INTERNAL_NAMESPACE_SOURCE_ENTER

InputPart::InputPart (MultiPartInputFile& multiPartFile, int partNumber)
{
    file = multiPartFile.getInputPart<InputFile> (partNumber);
}

const char*
InputPart::fileName () const
{
    return file->fileName ();
}

const Header&
InputPart::header () const
{
    return file->header ();
}

int
InputPart::version () const
{
    return file->version ();
}

void
InputPart::setFrameBuffer (const FrameBuffer& frameBuffer)
{
    file->setFrameBuffer (frameBuffer);
}

const FrameBuffer&
InputPart::frameBuffer () const
{
    return file->frameBuffer ();
}

bool
InputPart::isComplete () const
{
    return file->isComplete ();
}

bool
InputPart::isOptimizationEnabled () const
{
#if defined(_MSC_VER)
    __pragma(warning(push))
    __pragma(warning(disable: 4996))
#elif defined(__clang__) || defined(__GNUC__)
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#endif

    return file->isOptimizationEnabled ();

#if defined(_MSC_VER)
    __pragma(warning(pop))
#elif defined(__clang__) || defined(__GNUC__)
    #pragma GCC diagnostic pop
#endif
}

void
InputPart::readPixels (int scanLine1, int scanLine2)
{
    file->readPixels (scanLine1, scanLine2);
}

void
InputPart::readPixels (int scanLine)
{
    file->readPixels (scanLine);
}

void
InputPart::readPixels (
    const FrameBuffer& frameBuffer, int scanLine1, int scanLine2)
{
    file->readPixels (frameBuffer, scanLine1, scanLine2);
}

void
InputPart::rawPixelData (
    int firstScanLine, const char*& pixelData, int& pixelDataSize)
{
    file->rawPixelData (firstScanLine, pixelData, pixelDataSize);
}

void
InputPart::rawPixelDataToBuffer (
    int scanLine, char* pixelData, int& pixelDataSize) const
{
    file->rawPixelDataToBuffer (scanLine, pixelData, pixelDataSize);
}

void
InputPart::rawTileData (
    int&         dx,
    int&         dy,
    int&         lx,
    int&         ly,
    const char*& pixelData,
    int&         pixelDataSize)
{
    file->rawTileData (dx, dy, lx, ly, pixelData, pixelDataSize);
}

OPENEXR_IMF_INTERNAL_NAMESPACE_SOURCE_EXIT
