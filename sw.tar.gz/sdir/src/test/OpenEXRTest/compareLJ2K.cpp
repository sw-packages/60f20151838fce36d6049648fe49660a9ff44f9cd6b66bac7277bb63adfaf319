// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project.

#ifdef NDEBUG
#    undef NDEBUG
#endif

#include <assert.h>
#include <math.h>

#include "compareLJ2K.h"
#include "half.h"
#include <ImfCRgbaFile.h>

using namespace OPENEXR_IMF_NAMESPACE;
using namespace std;

bool
checkHTJ2KSample (double src, double tst)
{
    if (isnan (src) || isnan (tst))
    {
        return true;
    }

    if (fabs (src - tst) <= 1e-4)
    {
        return true;
    }

    if (fabs (src) >= 1e-5 && fabs ((src - tst) / src) <= 0.63)
    {
        return true;
    }

    return false;
}

bool
checkHTJ2KSample (unsigned int src, unsigned int tst)
{
    /* LJ2K compresses UINT losslessly today */
    return src == tst;
}

bool
checkHTJ2KSample (half src, half tst)
{
    if ((src.bits () & 0x7c00) == 0x7c00 ||
        (tst.bits () & 0x7c00) == 0x7c00)
        return true;
    bool g = checkHTJ2KSample ((double) src, (double) tst);
    if (!g) {
        std::cerr << "src=" << src << ", tst=" << tst << std::endl;
    }
    return g;
}

bool
checkHTJ2KSample (ImfHalf src, ImfHalf tst)
{
    half s, t;
    s.setBits (src);
    t.setBits (tst);
    return checkHTJ2KSample (s, t);
}
